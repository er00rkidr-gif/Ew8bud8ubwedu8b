package com.piphorror.mod.ai;

import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Mod.EventBusSubscriber(modid = "piphorror", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PipChatListener {
    private static final String WAKE_WORD = "pip";
    private static final int LISTEN_TICKS = 120;
    private static final double SEARCH_RADIUS = Math.max(96.0D, 48.0D);

    private static final Pattern FETCH_PATTERN = Pattern.compile(
        "(?:fetch|bring|get|find|grab|give)(?:\\s+me)?(?:\\s+(?:a|an|the|some|lots\\s+of|stack\\s+of|plenty\\s+of))?\\s+([a-z0-9_\\s]+)"
    );
    private static final Pattern KILL_PATTERN = Pattern.compile(
        "(?:kill|hunt(?:\\s+down)?|attack|slay|eliminate|fight|murder)(?:\\s+me)?(?:\\s+(?:a|an|the|that|this|some))?\\s+([a-z0-9_\\s]+)"
    );

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        if (player == null || !(player.level() instanceof ServerLevel level)) {
            return;
        }

        String rawMessage = event.getRawText().trim();
        String lower = rawMessage.toLowerCase(Locale.ROOT);
        PipChatListener nearestPip = findNearestPip(level, player);
        if (nearestPip == null) {
            return;
        }

        boolean mentionsPip = lower.contains(WAKE_WORD);
        boolean alreadyListening = nearestPip.isListening();

        if (!mentionsPip && !alreadyListening) {
            return;
        }

        if (mentionsPip) {
            boolean didListen = nearestPip.startLookoutListen(player, LISTEN_TICKS);
            if (!didListen) {
                player.displayClientMessage(Component.literal("§4...the tall white creature only stares."), true);
                PipAiClient.askPipAsync(level, player, nearestPip, rawMessage);
                return;
            }
        }

        String stripped = lower.replaceFirst(".*?\\b" + Pattern.quote(WAKE_WORD) + "\\b[,:!\\s]*", "").trim();
        if (stripped.isEmpty()) {
            stripped = lower;
        }

        // 1. "pip, follow me" / "pip, come back" / "pip, stop"
        if (stripped.contains("follow") || stripped.contains("come back") || stripped.contains("heel") || stripped.equals("stop")) {
            final PipChatListener targetPip = nearestPip;
            level.getServer().execute(() -> targetPip.returnToFollowOwner(player));
            return;
        }

        // 2. "pip, kill a <mob name or player>"
        String killTarget = extractKillTargetQuery(stripped);
        if (killTarget != null) {
            final PipChatListener targetPip = nearestPip;
            final String q = killTarget;
            level.getServer().execute(() -> targetPip.startHuntByQuery(player, q));
            return;
        }

        // 3. "pip, gather me some wood"
        if (isWoodGatherRequest(stripped)) {
            final PipChatListener targetPip = nearestPip;
            level.getServer().execute(() -> targetPip.startGatherWoodTask(player));
            return;
        }

        // 4. "pip, fetch me a <item>"
        String fetchQuery = extractFetchItemQuery(stripped);
        if (fetchQuery != null) {
            final PipChatListener targetPip = nearestPip;
            final String q = fetchQuery;
            level.getServer().execute(() -> {
                Item resolved = PipEventDirector.resolveItemByName(q);
                if (resolved == Items.AIR) {
                    player.sendSystemMessage(Component.literal("§8[Pip] §7I couldn't find an item called \"" + q + "\"."));
                } else {
                    int count = resolved.getMaxStackSize() > 1 ? 8 : 1;
                    targetPip.startFetchItemTask(player, resolved, count);
                }
            });
            return;
        }

        // 5. Matched horror/cover event ("stalk", "peek", "tree", etc.)
        String inlineCommand = extractEventFromText(lower);
        if (inlineCommand != null) {
            final PipChatListener targetPip = nearestPip;
            level.getServer().execute(() -> PipEventDirector.executeEvent(level, player, targetPip, inlineCommand));
            return;
        }

        // 6. Real Config-powered AI chat response when talking to Pip!
        if (mentionsPip) {
            final PipChatListener targetPip = nearestPip;
            PipAiClient.askPipAsync(level, player, targetPip, rawMessage);
        }
    }

    private static boolean isWoodGatherRequest(String text) {
        return (text.contains("wood") || text.contains("log") || text.contains("timber") || text.contains("tree"))
            && (text.contains("gather") || text.contains("chop") || text.contains("collect") || text.contains("get") || text.contains("bring") || text.contains("fetch"));
    }

    private static String extractKillTargetQuery(String text) {
        String clean = text.replaceAll("[^a-z0-9_\\s]", " ").replaceAll("\\s+", " ").trim();
        Matcher m = KILL_PATTERN.matcher(clean);
        if (m.find()) {
            String targetPart = m.group(1)
                .replaceAll("\\b(?:for me|please|pls|right now|now|nearby)\\b", "")
                .replaceAll("^(?:a|an|the|that|this|some)\\s+", "")
                .trim();
            if (!targetPart.isEmpty()) {
                return targetPart;
            }
        }
        return null;
    }

    private static String extractFetchItemQuery(String text) {
        String clean = text.replaceAll("[^a-z0-9_\\s]", " ").replaceAll("\\s+", " ").trim();
        Matcher m = FETCH_PATTERN.matcher(clean);
        if (m.find()) {
            String itemPart = m.group(1)
                .replaceAll("\\b(?:for me|please|pls|right now|now|for us)\\b", "")
                .replaceAll("^(?:a|an|the|some)\\s+", "")
                .trim();
            if (!itemPart.isEmpty()) {
                return itemPart;
            }
        }
        return null;
    }

    private static PipChatListener findNearestPip(ServerLevel level, ServerPlayer player) {
        AABB box = player.getBoundingBox().inflate(SEARCH_RADIUS);
        List<PipChatListener> list = level.getEntitiesOfClass(PipChatListener.class, box);
        return list.stream()
            .min(Comparator.comparingDouble(p -> p.distanceToSqr(player)))
            .orElse(null);
    }

    private static String extractEventFromText(String lower) {
        if (lower.contains("tree") || lower.contains("hide") || lower.contains("cover")) {
            return "stalk_behind";
        }
        if (lower.contains("lights") || lower.contains("dark") || lower.contains("torch") || lower.contains("flicker") || lower.contains("blackout")) {
            return "lights_flicker";
        }
        if (lower.contains("behind") || lower.contains("stalk") || lower.contains("follow") || lower.contains("watch") || lower.contains("sneak")) {
            return "stalk_behind";
        }
        if (lower.contains("knock") || lower.contains("door") || lower.contains("open") || lower.contains("let me in") || lower.contains("house")) {
            return "door_knock";
        }
        if (lower.contains("whisper") || lower.contains("talk") || lower.contains("speak") || lower.contains("mimic") || lower.contains("voice") || lower.contains("hello")) {
            return "mimic_whisper";
        }
        if (lower.contains("hunt") || lower.contains("chase") || lower.contains("attack") || lower.contains("kill") || lower.contains("run")) {
            return "hunt_escalation";
        }
        if (lower.contains("peek") || lower.contains("hallucination") || lower.contains("corner") || lower.contains("stare") || lower.contains("look")) {
            return "hallucination_decoy";
        }
        return null;
    }
}
