package com.piphorror.mod.world;

import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "piphorror", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PipWorldSpawner {
    private static final String DATA_KEY = "piphorror_world_spawner";

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ServerLevel overworld = player.server.overworld();
        PipWorldData data = overworld.getDataStorage().computeIfAbsent(
            PipWorldData::load,
            PipWorldData::new,
            DATA_KEY
        );

        if (data.initialPipSpawned) {
            return;
        }

        boolean alreadyPresent = !overworld.getEntitiesOfClass(
            PipChatListener.class,
            player.getBoundingBox().inflate(96.0D)
        ).isEmpty();

        if (!alreadyPresent) {
            EntityType<?> pipType = BuiltInRegistries.ENTITY_TYPE
                .getOptional(new ResourceLocation("piphorror", "pip"))
                .orElse(null);

            if (pipType != null) {
                double angle = overworld.random.nextDouble() * Math.PI * 2.0D;
                double dist = 10.0D + overworld.random.nextDouble() * 6.0D;
                int sx = (int) Math.round(player.getX() + Math.cos(angle) * dist);
                int sz = (int) Math.round(player.getZ() + Math.sin(angle) * dist);
                int sy = overworld.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, sx, sz);

                BlockPos spawnPos = new BlockPos(sx, sy, sz);
                Entity created = pipType.create(overworld);
                if (created instanceof PipChatListener pip) {
                    pip.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D, overworld.random.nextFloat() * 360.0F, 0.0F);
                    pip.setFakePip(false);
                    pip.setOwner(player);
                    overworld.addFreshEntity(pip);
                    player.sendSystemMessage(Component.literal(
                        "§a[Pip] §7Your mint-and-lavender pet spawned beside you! Say §e\"pip, kill a zombie\"§7, §e\"pip, gather wood\"§7, or paste an AI key in §econfig/piphorror-common.toml§7."
                    ));
                }
            }
        }

        data.initialPipSpawned = true;
        data.setDirty();
    }

    public static class PipWorldData extends SavedData {
        public boolean initialPipSpawned = false;

        public PipWorldData() {
        }

        public static PipWorldData load(CompoundTag tag) {
            PipWorldData d = new PipWorldData();
            d.initialPipSpawned = tag.getBoolean("InitialPipSpawned");
            return d;
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            tag.putBoolean("InitialPipSpawned", this.initialPipSpawned);
            return tag;
        }
    }
}
