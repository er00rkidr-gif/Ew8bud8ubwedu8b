# Pip AI Horror — Forge 1.20.1 Upgrade Guide

## What Was Added / Upgraded
1. **Original Friendly Pip + Tall White Monster Form & Embedded 64x64 PNG Textures**
   - `assets/piphorror/textures/entity/pip_horror.png` — pastel mint-green head, big white/black eyes, pink nose, rosy cheeks, stitched mouth, mint-to-lavender belly.
   - `assets/piphorror/textures/entity/pip_fake.png` — pale bone-white tall gaunt creature (~2.85 blocks tall) with bunny tail, floppy ears, wide staring ringed eyes, and dark hollow mouth.
2. **Always-Follow Pet Companion & Automatic World Spawn (`PipWorldSpawner.java` + `PipChatListener.java`)**
   - Automatically spawns Original Friendly Pip near you when creating/joining a new world—no `/summon` command required.
   - Binds to you as its owner and **follows you everywhere** (safely teleporting if >26 blocks away, opening doors, swimming).
3. **Smart Tree/Block Cover Stalking & Autonomous Tasks**
   - **Tree & Block Cover Peeking**: Scans nearby trees (`BlockTags.LOGS`) and 2-block-tall walls, slips behind cover out of your line of sight, and leans out to peek—even reacting if you stare straight at it.
   - `"pip, kill a <mob or player>"` — resolves any mob type (zombie, skeleton, spider, creeper, etc.) or online player name, sprints & pounces, eliminates the target, and returns to you.
   - `"pip, gather me some wood"` — breaks nearby tree logs and brings 16–32 logs back to your feet.
   - `"pip, fetch me a <item name>"` — resolves any Minecraft item via `BuiltInRegistries.ITEM` and delivers it to you.
4. **In-Mod AI Chat via Config (`config/piphorror-common.toml`)**
   - Launch Minecraft once to generate `.minecraft/config/piphorror-common.toml`.
   - Paste your Gemini or OpenAI API key into `apiKey = ""` under `[ai]`, then talk to Pip in-game chat (`"pip, how are you?"`)! Supports `[ACTION:...]` autonomous triggers too.
5. **Upgraded 500% Organic GeckoLib 4 Animations (`pip.animation.json`)**
   - Squash-and-stretch breathing curves, eye blinking (`eyes_glow`), cascading 4-segment tail wave inertia, overlapping head/ear delays, and snapping creep spasms.
6. **Brigadier Commands (`src/main/java/com/piphorror/mod/command/PipEventsCommand.java`)**
   - `/pip listen [player]`
   - `/pip follow [player]`
   - `/pip stalk [player]`
   - `/pip kill <mob_or_player>`
   - `/pip gather wood`
   - `/pip fetch <item_name>`
   - `/pip variant <real|fake>`
   - `/pip event <lights_flicker|stalk_behind|door_knock|mimic_whisper|hunt_escalation|hallucination_decoy> [player]`
